package com.example.poe2.ui.menu_client

import androidx.lifecycle.ViewModel

class MenuClientViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}