package com.example.poe2.ui.notifications_client

import androidx.lifecycle.ViewModel

class NotificationsClientViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}