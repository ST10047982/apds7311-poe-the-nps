package com.example.opsc7312poepart2_code.ui.forget_password_dentist

import androidx.lifecycle.ViewModel

class ForgetPasswordDentistViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}