package com.example.opsc7312poepart2_code.ui.book_app_client1

import androidx.lifecycle.ViewModel

class BookAppClient1ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}