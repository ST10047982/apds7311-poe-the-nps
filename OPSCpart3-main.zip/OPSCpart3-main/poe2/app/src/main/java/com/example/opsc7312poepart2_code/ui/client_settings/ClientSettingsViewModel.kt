package com.example.poe2.ui.client_settings

import androidx.lifecycle.ViewModel

class ClientSettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}