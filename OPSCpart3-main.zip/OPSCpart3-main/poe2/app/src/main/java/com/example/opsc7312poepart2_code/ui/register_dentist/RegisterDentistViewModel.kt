package com.example.opsc7312poepart2_code.ui.register_dentist

import androidx.lifecycle.ViewModel

class RegisterDentistViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}