package com.example.poe2.ui.book_appointment_dentist

import androidx.lifecycle.ViewModel

class BookAppointmentDentistViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}