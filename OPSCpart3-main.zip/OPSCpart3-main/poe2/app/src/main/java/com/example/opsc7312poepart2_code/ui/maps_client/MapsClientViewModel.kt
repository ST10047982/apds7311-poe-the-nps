package com.example.poe2.ui.maps_client

import androidx.lifecycle.ViewModel

class MapsClientViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}