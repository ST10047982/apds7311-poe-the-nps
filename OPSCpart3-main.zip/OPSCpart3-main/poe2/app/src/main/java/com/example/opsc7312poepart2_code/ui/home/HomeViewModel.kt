package com.example.poe2.ui.home

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
    // Empty ViewModel with only necessary code
}
