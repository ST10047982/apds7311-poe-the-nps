package com.example.poe2.ui.calendar_client

import androidx.lifecycle.ViewModel

class CalendarClientViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}