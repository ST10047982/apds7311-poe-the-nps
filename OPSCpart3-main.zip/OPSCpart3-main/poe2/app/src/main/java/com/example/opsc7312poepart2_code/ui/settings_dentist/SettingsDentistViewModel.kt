package com.example.poe2.ui.settings_dentist

import androidx.lifecycle.ViewModel

class SettingsDentistViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}