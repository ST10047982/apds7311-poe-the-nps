package com.example.opsc7312poepart2_code.ui.book_time_off

import androidx.lifecycle.ViewModel

class BookTimeOffViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}