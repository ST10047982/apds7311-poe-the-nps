package com.example.opsc7312poepart2_code.ui.register_client

import androidx.lifecycle.ViewModel

class RegisterClientViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}