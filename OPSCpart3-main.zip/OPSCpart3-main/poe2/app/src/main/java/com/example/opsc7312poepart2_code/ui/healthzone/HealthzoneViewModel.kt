package com.example.poe2.ui.healthzone

import androidx.lifecycle.ViewModel

class HealthzoneViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}