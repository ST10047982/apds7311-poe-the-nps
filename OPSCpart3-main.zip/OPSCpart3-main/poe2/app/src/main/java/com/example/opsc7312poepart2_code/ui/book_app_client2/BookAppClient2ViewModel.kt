package com.example.opsc7312poepart2_code.ui.book_app_client2

import androidx.lifecycle.ViewModel

class BookAppClient2ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}