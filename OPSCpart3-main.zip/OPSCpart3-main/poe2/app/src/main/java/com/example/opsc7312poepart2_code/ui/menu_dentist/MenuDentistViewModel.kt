package com.example.poe2.ui.menu_dentist

import androidx.lifecycle.ViewModel

class MenuDentistViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}